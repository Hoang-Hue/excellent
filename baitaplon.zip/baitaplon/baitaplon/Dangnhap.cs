﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
	public partial class Dangnhap : Form
	{
		public Dangnhap()
		{
			InitializeComponent();
		}

		private void btndangnhap_Click(object sender, EventArgs e)
		{
			string taikhoan = txttaikhoan.Text;
			string matkhau = txtmatkhau.Text;

			string chuoitruyvan = "exec dangnhap '"+taikhoan+"','"+matkhau+"'";
			DataTable a = DataProVider.Truyvan(chuoitruyvan);
			
			if(a.Rows.Count > 0)
			{
				Main main = new Main();
				main.Show();

			}
			else
			{
				MessageBox.Show("Tài khoản hoặc mật khẩu không chính xác");
			}
		}
	}
}
