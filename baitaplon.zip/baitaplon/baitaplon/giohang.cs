﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
	public partial class giohang : Form
	{
		public giohang()
		{
			InitializeComponent();
		}

		private void label3_Click(object sender, EventArgs e)
		{

		}
		public DataTable loadgiohang()
		{
			string chuoitruyvan = "select MaGH as ' Mã giỏ hàng ', Sl as ' Số lượng ' , MaMH as ' Mặt hàng ' from GioHang";
			return DataProVider.Truyvan(chuoitruyvan);
		}
		private void giohang_Load(object sender, EventArgs e)
		{
			dtgiohang.DataSource = loadgiohang();
			dtgiohang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}
		int rowSelected = -1;
		public bool Themgiohang()
		{

			string chuoitruyvan = @"insert into GioHang (MaGH , Sl, MaMH)
            values( '" + txtmagiohang.Text + "',  N'" + txtsl.Text + "',  N'" + txtmamathang.Text + "'  )";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnthem_Click(object sender, EventArgs e)
		{
			if (Themgiohang())
			{
				dtgiohang.DataSource = loadgiohang();
				MessageBox.Show("Thêm thành công");
			}
			else
			{
				MessageBox.Show("Lỗi");
			}
		}
		public bool Suagiohang()
		{

			string chuoitruyvan = @"   update GioHang set Sl = N'" + txtsl.Text + "',N'" + txtmamathang.Text + "'   " +
								  "where MaMH ='" + txtmamathang.Text + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnsua_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn giỏ  hàng ");
			}
			else
			{
				if (Suagiohang())
				{
					dtgiohang.DataSource = loadgiohang();
					MessageBox.Show("Sửa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}

			}
		}
		public bool Xoagiohang(int magiohang)
		{
			string chuoitruyvan = "delete from GioHang where MaGH = '" + magiohang + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnxoa_Click(object sender, EventArgs e)
		{
			if(rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn mặt hàng để xóa");

			}
			else
			{
				int magiohang= int.Parse(txtmagiohang.Text);
				if (Xoagiohang(magiohang))
				{
					dtgiohang.DataSource = loadgiohang();
					MessageBox.Show("Xóa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}
			}
		}
	}
	
}
