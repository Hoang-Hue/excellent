﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace baitaplon
{
	public partial class khachhang : Form
	{
		public khachhang()
		{
			InitializeComponent();
		}

		private void khachhang_Load(object sender, EventArgs e)
		{
			
		}
		public DataTable loadkhachhang()
		{
			string chuoitruyvan = "select Mak as ' Mã khách hàng' , TenK as 'Tên khách hàng' ,Diachi as 'Địa chỉ ' , SDT as ' SDT ' from KhachHang";
			return DataProVider.Truyvan(chuoitruyvan);
		}
		private void Khachhang_Load(object sender, EventArgs e)
		{
			dtkhachhang.DataSource = loadkhachhang();
			dtkhachhang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}
		int rowSelected = -1;
		public bool Themkhachhang()
		{

			string chuoitruyvan = @"insert into Khachhang(MaK, TenK, Diachi,SDT)
            values( '" + txtmak.Text + "',  N'" + txttenk.Text + "',  N'" + txtdiachi.Text + "' , N'" + txtsdt.Text + "')";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnthem_Click(object sender, EventArgs e)
		{
			if (Themkhachhang())
			{
				dtkhachhang.DataSource = loadkhachhang();
				MessageBox.Show("Thêm thành công");
			}
			else
			{
				MessageBox.Show("Lỗi");
			}
		}
		public bool Suakhachhang()
		{

			string chuoitruyvan = @"update khachhang set TenK = N'" + txttenk.Text + "',N'" + txtdiachi.Text + "' , N'" + txtsdt.Text + "'" +
				                  "where MaNV ='" + txtmak.Text + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnsua_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn khách hàng ");
			}
			else
			{
				if (Suakhachhang())
				{
					dtkhachhang.DataSource = loadkhachhang();
					MessageBox.Show("Sửa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}

			}
		
		}
		public bool Xoakhachhang(int makhachhang)
		{
			string chuoitruyvan = "delete from Nhanvien where MaK = '" + makhachhang  + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnxoa_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn khách hàng để xóa");

			}
			else
			{
				int makhachhang = int.Parse(txtmak.Text);
				if (Xoakhachhang(makhachhang))
				{
					dtkhachhang.DataSource = loadkhachhang();
					MessageBox.Show("Xóa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}


			}
		}
	}
}
