﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace baitaplon
{
	public partial class danhmuc : Form
	{
		public danhmuc()
		{
			InitializeComponent();
		}

		private void Madm_Click(object sender, EventArgs e)
		{

		}

		private void txtmadanhmuc_TextChanged(object sender, EventArgs e)
		{

		}
		 private void dtdanhmuc_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			
		}
		public DataTable loadDanhmuc()
		{
			string chuoitruyvan = " select Madanhmuc 'Mã danh mục',Tendanhmuc as 'Tên danh mục' from DanhMuc";
			return DataProVider.Truyvan(chuoitruyvan);
		}
		private void Danhmuc_Load(object sender, EventArgs e)
		{
			dtdanhmuc.DataSource = loadDanhmuc();
			dtdanhmuc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}
		int rowSelected = -1;
		public bool Themdanhmuc()
		{

			string chuoitruyvan = @"insert into Danhmuc(Madanhmuc, Tendanhmuc)
            values( '" + txtmadanhmuc.Text + "',  N'" + txttendanhmuc.Text + "' )";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}
		private void btnthem_Click(object sender, EventArgs e)
		{
			if (Themdanhmuc())
			{
				dtdanhmuc.DataSource = loadDanhmuc();
				MessageBox.Show("Thêm thành công");
			}
			else
			{
				MessageBox.Show("Lỗi");
			}
		}
		
		public bool Xoadanhmuc(int madanhmuc)
		{

			string chuoitruyvan = "delete from Danhmuc where Madanhmuc = '" + madanhmuc + "'";

			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}
		private void btnxoa_Click_1(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn danh mục để xóa");

			}
			else
			{
				int madanhmuc = int.Parse(txtmadanhmuc.Text);
				if (Xoadanhmuc(madanhmuc))
				{
					dtdanhmuc.DataSource = loadDanhmuc();
					MessageBox.Show("Xóa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}


			}
		}
		public bool Suadanhmuc()
		{
			
			string chuoitruyvan = @"update Danhmuc set Madanhmuc = N'" + txttendanhmuc.Text + "' where Madanhmuc ='" + txtmadanhmuc.Text + "'";

			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnSua_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn danh mục để sửa ");
			}
			else
			{
				if (Suadanhmuc())
				{
					dtdanhmuc.DataSource = loadDanhmuc();
					MessageBox.Show("Sửa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}

			}
		}

		private void danhmuc_Load_1(object sender, EventArgs e)
		{

		}
	}
}
