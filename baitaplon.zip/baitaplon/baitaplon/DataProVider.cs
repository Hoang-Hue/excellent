﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace baitaplon
{
	public class DataProVider
	{
		public static SqlConnection ketnoi()
		{
			string chuoiketnoi = @"Data Source=DESKTOP-JA5JLJD\SQLEX;Initial Catalog=lancuoi;Integrated Security=True";
			SqlConnection con = new SqlConnection(chuoiketnoi);
			con.Open();
			return con;
		}

		public static bool ExecuteNonQuery(string chuoitruyvan)
		{
			SqlCommand cmd = new SqlCommand(chuoitruyvan, ketnoi());
			int icmd = cmd.ExecuteNonQuery();
			ketnoi().Close();
			if (icmd > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
			try
			{
				
			}
			catch (Exception ex)
			{

				ketnoi().Close();
				return false;
			}
		}

		public static DataTable Truyvan(string chuoitruyvan)
		{
			try
			{
				SqlDataAdapter da = new SqlDataAdapter(chuoitruyvan, ketnoi());
				DataTable dt = new DataTable();
				da.Fill(dt);
				ketnoi().Close();
				return dt;
			}
			catch (Exception ex)
			{

				return null;
			}
		}

		public static string ExecuteScalar(string chuoitruyvan)
		{
			try
			{
				SqlCommand cmd = new SqlCommand(chuoitruyvan, ketnoi());
				string kq = cmd.ExecuteScalar().ToString();
				ketnoi().Close();
				return kq;
			}
			catch (Exception ex)
			{
				ketnoi().Close();
				return null;
			}
		}
	}
}

