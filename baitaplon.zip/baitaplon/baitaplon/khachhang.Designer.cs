﻿namespace baitaplon
{
	partial class khachhang
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnthem = new System.Windows.Forms.Button();
			this.btnsua = new System.Windows.Forms.Button();
			this.btnxoa = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtmak = new System.Windows.Forms.TextBox();
			this.txttenk = new System.Windows.Forms.TextBox();
			this.txtdiachi = new System.Windows.Forms.TextBox();
			this.txtsdt = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.dtkhachhang = new System.Windows.Forms.DataGridView();
			((System.ComponentModel.ISupportInitialize)(this.dtkhachhang)).BeginInit();
			this.SuspendLayout();
			// 
			// btnthem
			// 
			this.btnthem.Location = new System.Drawing.Point(178, 187);
			this.btnthem.Name = "btnthem";
			this.btnthem.Size = new System.Drawing.Size(75, 23);
			this.btnthem.TabIndex = 0;
			this.btnthem.Text = "Thêm";
			this.btnthem.UseVisualStyleBackColor = true;
			this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
			// 
			// btnsua
			// 
			this.btnsua.Location = new System.Drawing.Point(337, 186);
			this.btnsua.Name = "btnsua";
			this.btnsua.Size = new System.Drawing.Size(75, 23);
			this.btnsua.TabIndex = 1;
			this.btnsua.Text = "Sửa";
			this.btnsua.UseVisualStyleBackColor = true;
			this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
			// 
			// btnxoa
			// 
			this.btnxoa.Location = new System.Drawing.Point(488, 186);
			this.btnxoa.Name = "btnxoa";
			this.btnxoa.Size = new System.Drawing.Size(75, 23);
			this.btnxoa.TabIndex = 2;
			this.btnxoa.Text = "Xóa";
			this.btnxoa.UseVisualStyleBackColor = true;
			this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
			// 
			// label1
			// 
			this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(178, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Mã khách";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(181, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(59, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Tên khách";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(420, 51);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 13);
			this.label3.TabIndex = 5;
			this.label3.Text = "Địa chỉ";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(408, 110);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(0, 13);
			this.label4.TabIndex = 6;
			// 
			// txtmak
			// 
			this.txtmak.Location = new System.Drawing.Point(246, 41);
			this.txtmak.Name = "txtmak";
			this.txtmak.Size = new System.Drawing.Size(100, 20);
			this.txtmak.TabIndex = 7;
			// 
			// txttenk
			// 
			this.txttenk.Location = new System.Drawing.Point(246, 110);
			this.txttenk.Name = "txttenk";
			this.txttenk.Size = new System.Drawing.Size(100, 20);
			this.txttenk.TabIndex = 8;
			// 
			// txtdiachi
			// 
			this.txtdiachi.Location = new System.Drawing.Point(488, 41);
			this.txtdiachi.Name = "txtdiachi";
			this.txtdiachi.Size = new System.Drawing.Size(100, 20);
			this.txtdiachi.TabIndex = 9;
			// 
			// txtsdt
			// 
			this.txtsdt.Location = new System.Drawing.Point(488, 109);
			this.txtsdt.Name = "txtsdt";
			this.txtsdt.Size = new System.Drawing.Size(100, 20);
			this.txtsdt.TabIndex = 10;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(431, 113);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(29, 13);
			this.label5.TabIndex = 11;
			this.label5.Text = "SDT";
			// 
			// dtkhachhang
			// 
			this.dtkhachhang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dtkhachhang.Location = new System.Drawing.Point(83, 233);
			this.dtkhachhang.Name = "dtkhachhang";
			this.dtkhachhang.Size = new System.Drawing.Size(631, 171);
			this.dtkhachhang.TabIndex = 12;
			// 
			// khachhang
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.dtkhachhang);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtsdt);
			this.Controls.Add(this.txtdiachi);
			this.Controls.Add(this.txttenk);
			this.Controls.Add(this.txtmak);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnxoa);
			this.Controls.Add(this.btnsua);
			this.Controls.Add(this.btnthem);
			this.Name = "khachhang";
			this.Text = "khachhang";
			this.Load += new System.EventHandler(this.khachhang_Load);
			((System.ComponentModel.ISupportInitialize)(this.dtkhachhang)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnthem;
		private System.Windows.Forms.Button btnsua;
		private System.Windows.Forms.Button btnxoa;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtmak;
		private System.Windows.Forms.TextBox txttenk;
		private System.Windows.Forms.TextBox txtdiachi;
		private System.Windows.Forms.TextBox txtsdt;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.DataGridView dtkhachhang;
	}
}