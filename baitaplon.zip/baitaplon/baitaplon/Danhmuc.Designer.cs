﻿namespace baitaplon
{
	partial class danhmuc
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Madm = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtmadanhmuc = new System.Windows.Forms.TextBox();
			this.txttendanhmuc = new System.Windows.Forms.TextBox();
			this.dtdanhmuc = new System.Windows.Forms.DataGridView();
			this.btnthem = new System.Windows.Forms.Button();
			this.btnxoa = new System.Windows.Forms.Button();
			this.btnSua = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dtdanhmuc)).BeginInit();
			this.SuspendLayout();
			// 
			// Madm
			// 
			this.Madm.AutoSize = true;
			this.Madm.Location = new System.Drawing.Point(118, 53);
			this.Madm.Name = "Madm";
			this.Madm.Size = new System.Drawing.Size(72, 13);
			this.Madm.TabIndex = 0;
			this.Madm.Text = "Mã danh mục";
			this.Madm.Click += new System.EventHandler(this.Madm_Click);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(118, 118);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(76, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "Tên danh mục";
			// 
			// txtmadanhmuc
			// 
			this.txtmadanhmuc.Location = new System.Drawing.Point(204, 53);
			this.txtmadanhmuc.Name = "txtmadanhmuc";
			this.txtmadanhmuc.Size = new System.Drawing.Size(100, 20);
			this.txtmadanhmuc.TabIndex = 6;
			this.txtmadanhmuc.TextChanged += new System.EventHandler(this.txtmadanhmuc_TextChanged);
			// 
			// txttendanhmuc
			// 
			this.txttendanhmuc.Location = new System.Drawing.Point(204, 118);
			this.txttendanhmuc.Name = "txttendanhmuc";
			this.txttendanhmuc.Size = new System.Drawing.Size(100, 20);
			this.txttendanhmuc.TabIndex = 9;
			// 
			// dtdanhmuc
			// 
			this.dtdanhmuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dtdanhmuc.Location = new System.Drawing.Point(71, 217);
			this.dtdanhmuc.Name = "dtdanhmuc";
			this.dtdanhmuc.Size = new System.Drawing.Size(655, 193);
			this.dtdanhmuc.TabIndex = 12;
			this.dtdanhmuc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtdanhmuc_CellContentClick);
			// 
			// btnthem
			// 
			this.btnthem.Location = new System.Drawing.Point(186, 178);
			this.btnthem.Name = "btnthem";
			this.btnthem.Size = new System.Drawing.Size(75, 23);
			this.btnthem.TabIndex = 13;
			this.btnthem.Text = "Thêm";
			this.btnthem.UseVisualStyleBackColor = true;
			this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
			// 
			// btnxoa
			// 
			this.btnxoa.Location = new System.Drawing.Point(526, 178);
			this.btnxoa.Name = "btnxoa";
			this.btnxoa.Size = new System.Drawing.Size(75, 23);
			this.btnxoa.TabIndex = 14;
			this.btnxoa.Text = "Xóa";
			this.btnxoa.UseVisualStyleBackColor = true;
			this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click_1);
			// 
			// btnSua
			// 
			this.btnSua.Location = new System.Drawing.Point(356, 178);
			this.btnSua.Name = "btnSua";
			this.btnSua.Size = new System.Drawing.Size(75, 23);
			this.btnSua.TabIndex = 15;
			this.btnSua.Text = "Sửa";
			this.btnSua.UseVisualStyleBackColor = true;
			this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
			// 
			// danhmuc
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btnSua);
			this.Controls.Add(this.btnxoa);
			this.Controls.Add(this.btnthem);
			this.Controls.Add(this.dtdanhmuc);
			this.Controls.Add(this.txttendanhmuc);
			this.Controls.Add(this.txtmadanhmuc);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.Madm);
			this.Name = "danhmuc";
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.danhmuc_Load_1);
			((System.ComponentModel.ISupportInitialize)(this.dtdanhmuc)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label Madm;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtmadanhmuc;
		private System.Windows.Forms.TextBox txttendanhmuc;
		private System.Windows.Forms.DataGridView dtdanhmuc;
		private System.Windows.Forms.Button btnthem;
		private System.Windows.Forms.Button btnxoa;
		private System.Windows.Forms.Button btnSua;
	}
}