﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace baitaplon
{
	public partial class mathang: Form
	{
		public mathang()
		{
			InitializeComponent();
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}

		private void txtdongia_Load(object sender, EventArgs e)
		{

		}
		public DataTable loadmathang()
		{
			string chuoitruyvan = "select MaMH as 'Mã mặt hàng ', Madanhmuc as 'Mã danh mục' , TenMH as 'Tên mặt hàng' , Dongia as 'Đơn giá ', Slton as ' Số lượng tồn ' from MatHang";
			return DataProVider.Truyvan(chuoitruyvan);
		}
		private void mathang_Load(object sender, EventArgs e)
		{
			dtmathang.DataSource = loadmathang();
			dtmathang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}
		int rowSelected = -1;
		public bool Themmathang()
		{

			string chuoitruyvan = @"insert into MatHang(MaMH , Madanhmuc , TenMH, Dongia , Slton)
            values( '" + txtmamathang.Text + "',  N'" + txtmadanhmuc.Text + "',  N'" + txttenmathang.Text + "' , N'" + txtgia.Text + "' , N'" + txtslton.Text + "')";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnthem_Click(object sender, EventArgs e)
		{
			if (Themmathang())
			{
				dtmathang.DataSource = loadmathang();
				MessageBox.Show("Thêm thành công");
			}
			else
			{
				MessageBox.Show("Lỗi");
			}
		}
		public bool Suamathang()
		{

			string chuoitruyvan = @"update MatHang set Madanhmuc = N'" + txtmadanhmuc.Text + "',N'" + txttenmathang.Text + "' , N'" + txtgia.Text + "' , N'" + txtslton.Text + "' " +
								  "where MaMH ='" + txtmamathang.Text + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnsua_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn mặt hàng ");
			}
			else
			{
				if (Suamathang())
				{
					dtmathang.DataSource = loadmathang();
					MessageBox.Show("Sửa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}

			}

		}
		public bool Xoamathang(int mamathang)
		{
			string chuoitruyvan = "delete from MatHang where MaK = '" + mamathang + "'";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void btnxoa_Click(object sender, EventArgs e)
		{
			if (rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn mặt hàng để xóa");

			}
			else
			{
				int mamathang = int.Parse(txtmamathang.Text);
				if (Xoamathang(mamathang))
				{
					dtmathang.DataSource = loadmathang();
					MessageBox.Show("Xóa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}
			}
		}

		private void dtmathang_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}
	}
}
