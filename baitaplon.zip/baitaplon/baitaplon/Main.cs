﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
	public partial class Main : Form
	{
		public Main()
		{
			InitializeComponent();
		}

		private void btntaikhoan_Click(object sender, EventArgs e)
		{
			Taikhoan taikhoan = new Taikhoan();
			taikhoan.Show();
			
		}

		private void btnnhanvien_Click(object sender, EventArgs e)
		{
			Nhanvien nhanvien = new Nhanvien();
			nhanvien.Show();
		}

		private void btndanhmuc_Click(object sender, EventArgs e)
		{
			danhmuc danhmuc = new danhmuc();
			danhmuc.Show();
		}

		private void btnkhachhang_Click(object sender, EventArgs e)
		{
			khachhang khachhang = new khachhang();
			khachhang.Show();

		}

		private void btnmathang_Click(object sender, EventArgs e)
		{
			mathang mathang = new mathang();
			mathang.Show();
			


		}

		private void btngiohang_Click(object sender, EventArgs e)
		{
			giohang giohang = new giohang();
			giohang.Show();

		}
	}
}
