﻿namespace baitaplon
{
	partial class giohang
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtmagiohang = new System.Windows.Forms.TextBox();
			this.txtsl = new System.Windows.Forms.TextBox();
			this.txtmamathang = new System.Windows.Forms.TextBox();
			this.btnthem = new System.Windows.Forms.Button();
			this.btnsua = new System.Windows.Forms.Button();
			this.btnxoa = new System.Windows.Forms.Button();
			this.dtgiohang = new System.Windows.Forms.DataGridView();
			((System.ComponentModel.ISupportInitialize)(this.dtgiohang)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(113, 53);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Mã giỏ hàng";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(113, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(49, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Số lượng";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(113, 149);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(69, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Mã mặt hàng";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// txtmagiohang
			// 
			this.txtmagiohang.Location = new System.Drawing.Point(233, 53);
			this.txtmagiohang.Name = "txtmagiohang";
			this.txtmagiohang.Size = new System.Drawing.Size(100, 20);
			this.txtmagiohang.TabIndex = 3;
			// 
			// txtsl
			// 
			this.txtsl.Location = new System.Drawing.Point(233, 107);
			this.txtsl.Name = "txtsl";
			this.txtsl.Size = new System.Drawing.Size(100, 20);
			this.txtsl.TabIndex = 4;
			// 
			// txtmamathang
			// 
			this.txtmamathang.Location = new System.Drawing.Point(233, 149);
			this.txtmamathang.Name = "txtmamathang";
			this.txtmamathang.Size = new System.Drawing.Size(100, 20);
			this.txtmamathang.TabIndex = 5;
			// 
			// btnthem
			// 
			this.btnthem.Location = new System.Drawing.Point(107, 214);
			this.btnthem.Name = "btnthem";
			this.btnthem.Size = new System.Drawing.Size(75, 23);
			this.btnthem.TabIndex = 6;
			this.btnthem.Text = "Thêm";
			this.btnthem.UseVisualStyleBackColor = true;
			this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
			// 
			// btnsua
			// 
			this.btnsua.Location = new System.Drawing.Point(282, 213);
			this.btnsua.Name = "btnsua";
			this.btnsua.Size = new System.Drawing.Size(75, 23);
			this.btnsua.TabIndex = 7;
			this.btnsua.Text = "Sửa";
			this.btnsua.UseVisualStyleBackColor = true;
			this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
			// 
			// btnxoa
			// 
			this.btnxoa.Location = new System.Drawing.Point(473, 213);
			this.btnxoa.Name = "btnxoa";
			this.btnxoa.Size = new System.Drawing.Size(75, 23);
			this.btnxoa.TabIndex = 8;
			this.btnxoa.Text = "Xóa";
			this.btnxoa.UseVisualStyleBackColor = true;
			this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
			// 
			// dtgiohang
			// 
			this.dtgiohang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dtgiohang.Location = new System.Drawing.Point(57, 256);
			this.dtgiohang.Name = "dtgiohang";
			this.dtgiohang.Size = new System.Drawing.Size(659, 165);
			this.dtgiohang.TabIndex = 9;
			// 
			// giohang
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.dtgiohang);
			this.Controls.Add(this.btnxoa);
			this.Controls.Add(this.btnsua);
			this.Controls.Add(this.btnthem);
			this.Controls.Add(this.txtmamathang);
			this.Controls.Add(this.txtsl);
			this.Controls.Add(this.txtmagiohang);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "giohang";
			this.Text = "giohang";
			this.Load += new System.EventHandler(this.giohang_Load);
			((System.ComponentModel.ISupportInitialize)(this.dtgiohang)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtmagiohang;
		private System.Windows.Forms.TextBox txtsl;
		private System.Windows.Forms.TextBox txtmamathang;
		private System.Windows.Forms.Button btnthem;
		private System.Windows.Forms.Button btnsua;
		private System.Windows.Forms.Button btnxoa;
		private System.Windows.Forms.DataGridView dtgiohang;
	}
}