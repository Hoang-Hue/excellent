﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baitaplon
{
	public partial class Nhanvien : Form
	{
		public Nhanvien()
		{
			InitializeComponent();
		} 
		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			rowSelected = Convert.ToInt32(dvdanhsachnhanvien.CurrentRow.Index);
			txtmanhanvien.Text = dvdanhsachnhanvien.Rows[rowSelected].Cells["Mã nhân viên"].Value.ToString();
			txttennhanvien.Text = dvdanhsachnhanvien.Rows[rowSelected].Cells["Tên nhân viên"].Value.ToString();
			txtsodienthoai.Text = dvdanhsachnhanvien.Rows[rowSelected].Cells["Số điện thoại"].Value.ToString();
			txtdiachi.Text = dvdanhsachnhanvien.Rows[rowSelected].Cells["Địa chỉ"].Value.ToString();
			//cmbgioitinh.Text = dgvNhanVien.Rows[rowSelected].Cells["gioitinh"].Value.ToString();
			dtpngaysinh.Text = dvdanhsachnhanvien.Rows[rowSelected].Cells["Ngày sinh"].Value.ToString();
			
		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void label8_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (Themnhanvien())
			{
				dvdanhsachnhanvien.DataSource = loadnhanvien();
				MessageBox.Show("Thêm thành công");
			}
			else
			{
				MessageBox.Show("Lỗi");
			}
		}

		public DataTable loadnhanvien()
		{
			string chuoitruyvan = "select MaNV as 'Mã nhân viên',TenNV as 'Tên nhân viên',NgaySinh as 'Ngày sinh',SDT as 'Số điện thoại',Diachi as 'Địa chỉ' from NHANVIEN";
			return DataProVider.Truyvan(chuoitruyvan);
		}

		public bool Themnhanvien()
		
		{
			string ngaysinh = dtpngaysinh.Value.ToShortDateString();
			string chuoitruyvan = @"insert into NHANVIEN(MaNV,TenNV,NgaySinh,SDT,Diachi)
           values( '" + txtmanhanvien.Text + "',  N'" + txttennhanvien.Text + "' , '" + ngaysinh + "','" + txtsodienthoai.Text + "',N'" + txtdiachi.Text + "')";
			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		public bool Xoanhanvien(int manhanvien)
		{
			string chuoitruyvan = "delete from Nhanvien where MaNV = '" + manhanvien + "'";

			return DataProVider.ExecuteNonQuery(chuoitruyvan);

		}

		
		private void Nhanvien_Load(object sender, EventArgs e)
		{
			dvdanhsachnhanvien.DataSource = loadnhanvien();
			dvdanhsachnhanvien.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}

		int rowSelected = -1;
		private void btnxoa_Click(object sender, EventArgs e)
		{
			if(rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn nhân viên để xóa");

			}
			else
			{
				int manhanvien = int.Parse(txtmanhanvien.Text);
				if (Xoanhanvien(manhanvien))
				{
					dvdanhsachnhanvien.DataSource = loadnhanvien();
					MessageBox.Show("Xóa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}
				
				
			}
		}

		public bool Suanhanvien()
		{
			string ngaysinh = dtpngaysinh.Value.ToShortDateString();
			string chuoitruyvan = @"update NHANVIEN set TenNV = N'" + txttennhanvien.Text + "',ngaysinh ='" + ngaysinh + "',SDT='" + txtsodienthoai.Text + "',Diachi = N'" + txtdiachi.Text + "' where MaNV ='" + txtmanhanvien.Text + "'";

			return DataProVider.ExecuteNonQuery(chuoitruyvan);
		}

		private void button3_Click(object sender, EventArgs e)
		{
			if(rowSelected == -1)
			{
				MessageBox.Show("Bạn chưa chọn nhân viên ");
			}
			else
			{
				if (Suanhanvien())
				{
					dvdanhsachnhanvien.DataSource = loadnhanvien();
					MessageBox.Show("Sửa thành công");
				}
				else
				{
					MessageBox.Show("Lỗi");
				}
				
			}
		}

		private void txtmanhanvien_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
