﻿namespace baitaplon
{
	partial class Nhanvien
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnthem = new System.Windows.Forms.Button();
			this.dvdanhsachnhanvien = new System.Windows.Forms.DataGridView();
			this.txtmanhanvien = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.txttennhanvien = new System.Windows.Forms.TextBox();
			this.txtdiachi = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.txtsodienthoai = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnxoa = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.dtpngaysinh = new System.Windows.Forms.DateTimePicker();
			this.cmbtentaikhoan = new System.Windows.Forms.ComboBox();
			((System.ComponentModel.ISupportInitialize)(this.dvdanhsachnhanvien)).BeginInit();
			this.SuspendLayout();
			// 
			// btnthem
			// 
			this.btnthem.Location = new System.Drawing.Point(237, 144);
			this.btnthem.Name = "btnthem";
			this.btnthem.Size = new System.Drawing.Size(75, 23);
			this.btnthem.TabIndex = 0;
			this.btnthem.Text = "Thêm";
			this.btnthem.UseVisualStyleBackColor = true;
			this.btnthem.Click += new System.EventHandler(this.button1_Click);
			// 
			// dvdanhsachnhanvien
			// 
			this.dvdanhsachnhanvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dvdanhsachnhanvien.Location = new System.Drawing.Point(12, 183);
			this.dvdanhsachnhanvien.Name = "dvdanhsachnhanvien";
			this.dvdanhsachnhanvien.Size = new System.Drawing.Size(776, 255);
			this.dvdanhsachnhanvien.TabIndex = 1;
			this.dvdanhsachnhanvien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
			// 
			// txtmanhanvien
			// 
			this.txtmanhanvien.Location = new System.Drawing.Point(204, 22);
			this.txtmanhanvien.Name = "txtmanhanvien";
			this.txtmanhanvien.Size = new System.Drawing.Size(123, 20);
			this.txtmanhanvien.TabIndex = 2;
			this.txtmanhanvien.TextChanged += new System.EventHandler(this.txtmanhanvien_TextChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(77, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Mã nhân viên";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(77, 59);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(0, 13);
			this.label2.TabIndex = 4;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(77, 59);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 13);
			this.label3.TabIndex = 5;
			this.label3.Text = "Tên nhân viên";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(295, 261);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(0, 13);
			this.label5.TabIndex = 11;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(295, 217);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(0, 13);
			this.label6.TabIndex = 10;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(295, 217);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(0, 13);
			this.label7.TabIndex = 9;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(295, 183);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(0, 13);
			this.label8.TabIndex = 8;
			this.label8.Click += new System.EventHandler(this.label8_Click);
			// 
			// txttennhanvien
			// 
			this.txttennhanvien.Location = new System.Drawing.Point(204, 56);
			this.txttennhanvien.Name = "txttennhanvien";
			this.txttennhanvien.Size = new System.Drawing.Size(123, 20);
			this.txttennhanvien.TabIndex = 7;
			// 
			// txtdiachi
			// 
			this.txtdiachi.Location = new System.Drawing.Point(529, 58);
			this.txtdiachi.Name = "txtdiachi";
			this.txtdiachi.Size = new System.Drawing.Size(135, 20);
			this.txtdiachi.TabIndex = 18;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(402, 65);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(40, 13);
			this.label9.TabIndex = 17;
			this.label9.Text = "Địa chỉ";
			// 
			// txtsodienthoai
			// 
			this.txtsodienthoai.Location = new System.Drawing.Point(529, 15);
			this.txtsodienthoai.Name = "txtsodienthoai";
			this.txtsodienthoai.Size = new System.Drawing.Size(135, 20);
			this.txtsodienthoai.TabIndex = 16;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(402, 22);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(70, 13);
			this.label4.TabIndex = 15;
			this.label4.Text = "Số điện thoại";
			// 
			// btnxoa
			// 
			this.btnxoa.Location = new System.Drawing.Point(367, 144);
			this.btnxoa.Name = "btnxoa";
			this.btnxoa.Size = new System.Drawing.Size(75, 23);
			this.btnxoa.TabIndex = 19;
			this.btnxoa.Text = "Xóa";
			this.btnxoa.UseVisualStyleBackColor = true;
			this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(497, 144);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(75, 23);
			this.button3.TabIndex = 20;
			this.button3.Text = "Sửa";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(79, 99);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(73, 13);
			this.label10.TabIndex = 21;
			this.label10.Text = "Tên tài khoản";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(402, 104);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(54, 13);
			this.label11.TabIndex = 23;
			this.label11.Text = "Ngày sinh";
			// 
			// dtpngaysinh
			// 
			this.dtpngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpngaysinh.Location = new System.Drawing.Point(529, 96);
			this.dtpngaysinh.Name = "dtpngaysinh";
			this.dtpngaysinh.Size = new System.Drawing.Size(135, 20);
			this.dtpngaysinh.TabIndex = 24;
			// 
			// cmbtentaikhoan
			// 
			this.cmbtentaikhoan.FormattingEnabled = true;
			this.cmbtentaikhoan.Location = new System.Drawing.Point(204, 91);
			this.cmbtentaikhoan.Name = "cmbtentaikhoan";
			this.cmbtentaikhoan.Size = new System.Drawing.Size(123, 21);
			this.cmbtentaikhoan.TabIndex = 22;
			// 
			// Nhanvien
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.dtpngaysinh);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.cmbtentaikhoan);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.btnxoa);
			this.Controls.Add(this.txtdiachi);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtsodienthoai);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txttennhanvien);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtmanhanvien);
			this.Controls.Add(this.dvdanhsachnhanvien);
			this.Controls.Add(this.btnthem);
			this.Name = "Nhanvien";
			this.Text = "1";
			this.Load += new System.EventHandler(this.Nhanvien_Load);
			((System.ComponentModel.ISupportInitialize)(this.dvdanhsachnhanvien)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnthem;
		private System.Windows.Forms.DataGridView dvdanhsachnhanvien;
		private System.Windows.Forms.TextBox txtmanhanvien;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txttennhanvien;
		private System.Windows.Forms.TextBox txtdiachi;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtsodienthoai;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnxoa;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.DateTimePicker dtpngaysinh;
		private System.Windows.Forms.ComboBox cmbtentaikhoan;
	}
}