﻿namespace baitaplon
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btntaikhoan = new System.Windows.Forms.Button();
			this.btnthongke = new System.Windows.Forms.Button();
			this.btndanhmuc = new System.Windows.Forms.Button();
			this.btngiohang = new System.Windows.Forms.Button();
			this.btnmathang = new System.Windows.Forms.Button();
			this.btnnhanvien = new System.Windows.Forms.Button();
			this.btnkhachhang = new System.Windows.Forms.Button();
			this.btnhoadon = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btntaikhoan
			// 
			this.btntaikhoan.Location = new System.Drawing.Point(32, 272);
			this.btntaikhoan.Name = "btntaikhoan";
			this.btntaikhoan.Size = new System.Drawing.Size(110, 74);
			this.btntaikhoan.TabIndex = 0;
			this.btntaikhoan.Text = "Tài Khoản";
			this.btntaikhoan.UseVisualStyleBackColor = true;
			this.btntaikhoan.Click += new System.EventHandler(this.btntaikhoan_Click);
			// 
			// btnthongke
			// 
			this.btnthongke.Location = new System.Drawing.Point(374, 272);
			this.btnthongke.Name = "btnthongke";
			this.btnthongke.Size = new System.Drawing.Size(121, 74);
			this.btnthongke.TabIndex = 1;
			this.btnthongke.Text = "Thống Kê";
			this.btnthongke.UseVisualStyleBackColor = true;
			// 
			// btndanhmuc
			// 
			this.btndanhmuc.Location = new System.Drawing.Point(533, 121);
			this.btndanhmuc.Name = "btndanhmuc";
			this.btndanhmuc.Size = new System.Drawing.Size(117, 75);
			this.btndanhmuc.TabIndex = 2;
			this.btndanhmuc.Text = "Danh Mục";
			this.btndanhmuc.UseVisualStyleBackColor = true;
			this.btndanhmuc.Click += new System.EventHandler(this.btndanhmuc_Click);
			// 
			// btngiohang
			// 
			this.btngiohang.Location = new System.Drawing.Point(192, 121);
			this.btngiohang.Name = "btngiohang";
			this.btngiohang.Size = new System.Drawing.Size(124, 75);
			this.btngiohang.TabIndex = 3;
			this.btngiohang.Text = "Giỏ hàng";
			this.btngiohang.UseVisualStyleBackColor = true;
			this.btngiohang.Click += new System.EventHandler(this.btngiohang_Click);
			// 
			// btnmathang
			// 
			this.btnmathang.Location = new System.Drawing.Point(374, 121);
			this.btnmathang.Name = "btnmathang";
			this.btnmathang.Size = new System.Drawing.Size(113, 75);
			this.btnmathang.TabIndex = 4;
			this.btnmathang.Text = "Mặt Hàng";
			this.btnmathang.UseVisualStyleBackColor = true;
			this.btnmathang.Click += new System.EventHandler(this.btnmathang_Click);
			// 
			// btnnhanvien
			// 
			this.btnnhanvien.Location = new System.Drawing.Point(32, 121);
			this.btnnhanvien.Name = "btnnhanvien";
			this.btnnhanvien.Size = new System.Drawing.Size(111, 75);
			this.btnnhanvien.TabIndex = 5;
			this.btnnhanvien.Text = "Nhân viên";
			this.btnnhanvien.UseVisualStyleBackColor = true;
			this.btnnhanvien.Click += new System.EventHandler(this.btnnhanvien_Click);
			// 
			// btnkhachhang
			// 
			this.btnkhachhang.Location = new System.Drawing.Point(192, 272);
			this.btnkhachhang.Name = "btnkhachhang";
			this.btnkhachhang.Size = new System.Drawing.Size(124, 74);
			this.btnkhachhang.TabIndex = 6;
			this.btnkhachhang.Text = "Khách hàng ";
			this.btnkhachhang.UseVisualStyleBackColor = true;
			this.btnkhachhang.Click += new System.EventHandler(this.btnkhachhang_Click);
			// 
			// btnhoadon
			// 
			this.btnhoadon.Location = new System.Drawing.Point(533, 272);
			this.btnhoadon.Name = "btnhoadon";
			this.btnhoadon.Size = new System.Drawing.Size(117, 74);
			this.btnhoadon.TabIndex = 7;
			this.btnhoadon.Text = "Hóa đơn";
			this.btnhoadon.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
			this.label1.Location = new System.Drawing.Point(252, 39);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(171, 13);
			this.label1.TabIndex = 8;
			this.label1.Text = "Quản lý bán hàng thời trang ELISE";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(711, 450);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnhoadon);
			this.Controls.Add(this.btnkhachhang);
			this.Controls.Add(this.btnnhanvien);
			this.Controls.Add(this.btnmathang);
			this.Controls.Add(this.btngiohang);
			this.Controls.Add(this.btndanhmuc);
			this.Controls.Add(this.btnthongke);
			this.Controls.Add(this.btntaikhoan);
			this.Name = "Main";
			this.Text = "Phần mềm quản lý bán hàng thời trang";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btntaikhoan;
		private System.Windows.Forms.Button btnthongke;
		private System.Windows.Forms.Button btndanhmuc;
		private System.Windows.Forms.Button btngiohang;
		private System.Windows.Forms.Button btnmathang;
		private System.Windows.Forms.Button btnnhanvien;
		private System.Windows.Forms.Button btnkhachhang;
		private System.Windows.Forms.Button btnhoadon;
		private System.Windows.Forms.Label label1;
	}
}