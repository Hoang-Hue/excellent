﻿namespace baitaplon
{
	partial class mathang
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtmamathang = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtsoluongton = new System.Windows.Forms.Label();
			this.txtmamathnag = new System.Windows.Forms.TextBox();
			this.txtmadanhmuc = new System.Windows.Forms.TextBox();
			this.txtslton = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txttenmathang = new System.Windows.Forms.TextBox();
			this.txtgia = new System.Windows.Forms.TextBox();
			this.dtmathang = new System.Windows.Forms.DataGridView();
			this.btnthem = new System.Windows.Forms.Button();
			this.btnsua = new System.Windows.Forms.Button();
			this.btnxoa = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dtmathang)).BeginInit();
			this.SuspendLayout();
			// 
			// txtmamathang
			// 
			this.txtmamathang.AutoSize = true;
			this.txtmamathang.Location = new System.Drawing.Point(97, 46);
			this.txtmamathang.Name = "txtmamathang";
			this.txtmamathang.Size = new System.Drawing.Size(72, 13);
			this.txtmamathang.TabIndex = 0;
			this.txtmamathang.Text = " Mã mặt hàng";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(98, 100);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Mã danh mục ";
			// 
			// txtsoluongton
			// 
			this.txtsoluongton.AutoSize = true;
			this.txtsoluongton.Location = new System.Drawing.Point(337, 103);
			this.txtsoluongton.Name = "txtsoluongton";
			this.txtsoluongton.Size = new System.Drawing.Size(67, 13);
			this.txtsoluongton.TabIndex = 4;
			this.txtsoluongton.Text = "Số lượng tồn";
			// 
			// txtmamathnag
			// 
			this.txtmamathnag.Location = new System.Drawing.Point(191, 46);
			this.txtmamathnag.Name = "txtmamathnag";
			this.txtmamathnag.Size = new System.Drawing.Size(100, 20);
			this.txtmamathnag.TabIndex = 5;
			// 
			// txtmadanhmuc
			// 
			this.txtmadanhmuc.Location = new System.Drawing.Point(191, 100);
			this.txtmadanhmuc.Name = "txtmadanhmuc";
			this.txtmadanhmuc.Size = new System.Drawing.Size(100, 20);
			this.txtmadanhmuc.TabIndex = 6;
			// 
			// txtslton
			// 
			this.txtslton.Location = new System.Drawing.Point(425, 100);
			this.txtslton.Name = "txtslton";
			this.txtslton.Size = new System.Drawing.Size(100, 20);
			this.txtslton.TabIndex = 9;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(98, 162);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(73, 13);
			this.label1.TabIndex = 10;
			this.label1.Text = "Tên mặt hàng";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(360, 49);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(44, 13);
			this.label3.TabIndex = 11;
			this.label3.Text = "Đơn giá";
			// 
			// txttenmathang
			// 
			this.txttenmathang.Location = new System.Drawing.Point(191, 159);
			this.txttenmathang.Name = "txttenmathang";
			this.txttenmathang.Size = new System.Drawing.Size(100, 20);
			this.txttenmathang.TabIndex = 12;
			// 
			// txtgia
			// 
			this.txtgia.Location = new System.Drawing.Point(425, 43);
			this.txtgia.Name = "txtgia";
			this.txtgia.Size = new System.Drawing.Size(100, 20);
			this.txtgia.TabIndex = 13;
			// 
			// dtmathang
			// 
			this.dtmathang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dtmathang.Location = new System.Drawing.Point(35, 240);
			this.dtmathang.Name = "dtmathang";
			this.dtmathang.Size = new System.Drawing.Size(741, 198);
			this.dtmathang.TabIndex = 14;
			this.dtmathang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtmathang_CellContentClick);
			// 
			// btnthem
			// 
			this.btnthem.Location = new System.Drawing.Point(125, 195);
			this.btnthem.Name = "btnthem";
			this.btnthem.Size = new System.Drawing.Size(75, 23);
			this.btnthem.TabIndex = 15;
			this.btnthem.Text = "Thêm";
			this.btnthem.UseVisualStyleBackColor = true;
			this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
			// 
			// btnsua
			// 
			this.btnsua.Location = new System.Drawing.Point(340, 195);
			this.btnsua.Name = "btnsua";
			this.btnsua.Size = new System.Drawing.Size(75, 23);
			this.btnsua.TabIndex = 16;
			this.btnsua.Text = "Sửa";
			this.btnsua.UseVisualStyleBackColor = true;
			this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
			// 
			// btnxoa
			// 
			this.btnxoa.Location = new System.Drawing.Point(560, 195);
			this.btnxoa.Name = "btnxoa";
			this.btnxoa.Size = new System.Drawing.Size(75, 23);
			this.btnxoa.TabIndex = 17;
			this.btnxoa.Text = "Xóa";
			this.btnxoa.UseVisualStyleBackColor = true;
			this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
			// 
			// txtdongia
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btnxoa);
			this.Controls.Add(this.btnsua);
			this.Controls.Add(this.btnthem);
			this.Controls.Add(this.dtmathang);
			this.Controls.Add(this.txtgia);
			this.Controls.Add(this.txttenmathang);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtslton);
			this.Controls.Add(this.txtmadanhmuc);
			this.Controls.Add(this.txtmamathnag);
			this.Controls.Add(this.txtsoluongton);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtmamathang);
			this.Name = "txtdongia";
			this.Text = "Mathang";
			this.Load += new System.EventHandler(this.txtdongia_Load);
			((System.ComponentModel.ISupportInitialize)(this.dtmathang)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label txtmamathang;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label txtsoluongton;
		private System.Windows.Forms.TextBox txtmamathnag;
		private System.Windows.Forms.TextBox txtmadanhmuc;
		private System.Windows.Forms.TextBox txtslton;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txttenmathang;
		private System.Windows.Forms.TextBox txtgia;
		private System.Windows.Forms.DataGridView dtmathang;
		private System.Windows.Forms.Button btnthem;
		private System.Windows.Forms.Button btnsua;
		private System.Windows.Forms.Button btnxoa;
	}
}